package com.example.mypaint.model;

import javafx.scene.Node;

public interface Shape {
    Node draw();
}
