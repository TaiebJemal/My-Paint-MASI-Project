package com.example.mypaint.logging;

public interface LoggerStrategy {
    void log(String message);
}
